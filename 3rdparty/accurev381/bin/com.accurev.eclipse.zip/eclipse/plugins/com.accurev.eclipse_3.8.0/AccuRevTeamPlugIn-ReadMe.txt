===============================================================
AccuRev Team Provider Plug-In for Eclipse Platform, Version 3.8
===============================================================

August 26, 2005

ZIP archive com.accurev.eclipse.zip contains the files that implement
the AccuRev Team Provider plug-in for the Eclipse Platform.  The ZIP
archive contains the following files:

AccuRevIDECommon.jar
    JAR file containing the AccuRev Java API classes.

AccuRevTeamPlugIn-ReadMe.txt
    This read-me file.

eclispe.jar
    JAR file containing the AccuRev Team plug-in specific classes.

plugin.xml
    XML description of the AccuRev/Eclipse plug-in.

xercesImpl.jar
xml-apis.jar
    JAR files containing the XML classes.

*.gif
    The images and icons referenced by the plug-in.


Tested Eclipse Platforms
------------------------

Version 3.8 of the AccuRev Team Provider Plug-In has been tested with:

    Eclipse 2.1.2
    Eclipse 3.1.0


Installation
------------

1. Unzip the contents of the com.accurev.eclipse.zip into the Eclipse
installation area. The relative path for each file in the ZIP archive is:

    eclipse\plugins\com.accurev.eclipse_<Version>

2. For each Eclipse workspace that contains AccuRev-controlled files,
start Eclipse with the -clean option:

    eclipse -clean <Eclipse-Workspace-Path>

Why? Some Eclipse versions cache plug-in information in Eclipse
workspaces, and do not recognize changes in the plug-in classes or
version. Using "-clean" removes any existing plug-in cache information.
You need to use this option at most once per Eclipse workspace.

3. Invoke the Team > Share Project on each existing Eclipse project that
contains AccuRev-controlled files, and choose the AccuRev repository type.

- When the Share Project menu item is disabled or the Share Project
command fails with the message, "The chosen operation is not enabled",
(1) Remove the Eclipse project without deleting the project's files,
(2) Recreate the project, and (3) Invoke the Share Project command again.

4. Delete any older installed versions of the AccuRev Team Provider
plug-in from the Eclipse plugins. Each one is stored as a subdirectory
named com.accurev.eclipse_<Version>.


Changes Made and Issues Fixed in the AccuRev Team Provider Plug-In
------------------------------------------------------------------

Version 3.8
...........

- Removed the AccuRev Plug-In drop-down menu

- Added support for the following actions through the Team menu:
    Keep and Promote
    Defunct
    Update AccuRev Workspace Preview
    AccuRev Workspace Information
    Search: Modified
    Search: Kept
    Search: Non-member
    Search: Default Group
    Search: Overlap
    Search: Mod. in Def. Grp.
    Search: Defunct

- Changed the status triangle icons changed (resources not under AccuRev
control have no icon):
    Overlap:  Yellow - Pointing Upper/Left
    Stale:    Orange - Pointing Up
    Kept:     Blue   - Pointing Right
    Modified: Teal   - Pointing Down
    Backed:   Green  - Pointing Up
    Member:   Gray   - Pointing Right

- Searches View supports selection from multiple Eclipse projects when
all projects reference the same AccuRev workspace

- Added a Select Issues dialog when change-package-based integration is
enabled

- Added a Select Issues dialog when transaction-based integration is
enabled

- 6100: Support 'Update Preview' from within Eclipse

- 6241: Do not enable promotion if at least one selected file has an
overlap status

- 6732: Allow the user to Keep and Promote in a single action

- 6748: Make icons for Modified and Kept files more obvious

- 6749: Move icons out of the JAR file so users can specific their own
icons

- 7046: Support the defunct action

- 7314: Refactor the Eclipse/Java IDE Integration

- 7436: Display a dialog with a list of issues when an Issue Number is needed

- 7447: Support "Workspace Information" from within Eclipse

- 7514: Build the Eclipse Plug-In with JDK 1.3.1 to ensure compatibility
