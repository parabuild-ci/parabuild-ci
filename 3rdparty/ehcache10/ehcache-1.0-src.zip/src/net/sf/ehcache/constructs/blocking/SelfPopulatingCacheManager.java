/* ====================================================================
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 2003 - 2004 Greg Luck.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowlegement:
 *       "This product includes software developed by Greg Luck
 *       (http://sourceforge.net/users/gregluck) and contributors.
 *       See http://sourceforge.net/project/memberlist.php?group_id=93232
 *       for a list of contributors"
 *    Alternately, this acknowledgement may appear in the software itself,
 *    if and wherever such third-party acknowlegements normally appear.
 *
 * 4. The names "EHCache" must not be used to endorse or promote products
 *    derived from this software without prior written permission. For written
 *    permission, please contact Greg Luck (gregluck at users.sourceforge.net).
 *
 * 5. Products derived from this software may not be called "EHCache"
 *    nor may "EHCache" appear in their names without prior written
 *    permission of Greg Luck.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL GREG LUCK OR OTHER
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by contributors
 * individuals on behalf of the EHCache project.  For more
 * information on EHCache, please see <http://ehcache.sourceforge.net/>.
 *
 */

package sf.net.ehcache.constructs.blocking;

import net.sf.ehcache.CacheException;
import net.sf.ehcache.constructs.blocking.BlockingCacheManager;
import net.sf.ehcache.constructs.blocking.CacheEntryFactory;
import net.sf.ehcache.constructs.blocking.SelfPopulatingCache;
import net.sf.ehcache.constructs.blocking.UpdatingCacheEntryFactory;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * A cache manager for self populating caches
 * @version $Id: SelfPopulatingCacheManager.java,v 1.5 2004/09/26 11:41:44 gregluck Exp $
 * @author <a href="mailto:gluck@thoughtworks.com">Greg Luck</a>
 */
public abstract class SelfPopulatingCacheManager extends BlockingCacheManager {

    /**
     * Constructor. Caches are set up here.
     */
    public SelfPopulatingCacheManager() throws CacheException {
        super();
        setupCaches();
    }

    /**
     * Gets a self-populating cache.
     * @param name the name of the cache
     * @throws CacheException If the cache does not exist.
     */
    public SelfPopulatingCache getSelfPopulatingCache(final String name) throws CacheException {
        // Create the cache
        final SelfPopulatingCache cache = (SelfPopulatingCache) caches.get(name);
        if (cache == null) {
            throw new CacheException("Cache " + name + " cannot be retrieved. Please check ehcache.xml");
        }
        return cache;
    }

    /**
     * Refreshes all caches.
     */
    public void refreshAll() throws Exception {
        final List caches = getCaches();
        for (int i = 0; i < caches.size(); i++) {
            final SelfPopulatingCache cache = (SelfPopulatingCache) caches.get(i);
            cache.refresh();
        }
    }

    /**
     * Refreshes a SelfPopulatingCache. The cache will repopulate itself.
     * @param name the name of the cace
     * @throws CacheException
     */
    public void refresh(final String name) throws CacheException {
        final SelfPopulatingCache cache = (SelfPopulatingCache) getSelfPopulatingCache(name);
        cache.refresh();
    }

    /**
     * Refreshes a single entry in a SelfPopulatingCache.
     * The old entry is discarded and then requested, causing it to be populated.
     * Note: Used by tests only, do not use in production.
     */
    public void refreshEntry(final String cacheName, final Serializable key) throws Exception {
        final SelfPopulatingCache cache = (SelfPopulatingCache) getSelfPopulatingCache(cacheName);
        cache.put(key, null);
        cache.get(key);
    }

    /**
     * Creates a self-populating cache.
     */
    protected synchronized SelfPopulatingCache createSelfPopulatingCache(final String name,
            final CacheEntryFactory factory) throws CacheException {
        if (caches.containsKey(name)) {
            throw new CacheException("A cache with name \"" + name + "\" already exists.");
        }

        // Create the cache
        final SelfPopulatingCache cache = new SelfPopulatingCache(name, factory);
        caches.put(name, cache);
        return cache;
    }

    /**
     * Creates a self-populating cache with an UpdatingCacheEntryFactory
     */
    protected synchronized SelfPopulatingCache createUpdatingSelfPopulatingCache(final String name,
            final UpdatingCacheEntryFactory factory) throws CacheException {
        if (caches.containsKey(name)) {
            throw new CacheException("A cache with name \"" + name + "\" already exists.");
        }

        // Create the cache
        final SelfPopulatingCache cache = new SelfPopulatingCache(name, factory);
        caches.put(name, cache);
        return cache;
    }

    /** Builds the set of caches. Returns a copy so that the monitor can be released.  */
    protected synchronized List getCaches() {
        final ArrayList caches = new ArrayList();
        caches.addAll(this.caches.values());
        return caches;
    }

    /**
     * Sets up the caches used by the manager.
     **/
    protected synchronized void setupCaches() throws CacheException {
        doSetupCaches();
    }

    /**
     * A template method to set up caches. It is wrapped by {@link #setupCaches}
     * to ensure that caches are created within a synchronized method.
     * <p/>
     * Implementations of this method should typically call {@link #createSelfPopulatingCache(java.lang.String, net.sf.ehcache.constructs.blocking.CacheEntryFactory)},
     * or {@link #createUpdatingSelfPopulatingCache(java.lang.String, net.sf.ehcache.constructs.blocking.UpdatingCacheEntryFactory)}
     * for each required cache.
     */
    protected abstract void doSetupCaches() throws CacheException;
}
